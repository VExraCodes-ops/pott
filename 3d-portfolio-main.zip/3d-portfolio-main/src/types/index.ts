export interface Link {
  title: string;
  href: string;
  thumbnail: string;
  target?: string;
}
